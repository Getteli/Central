<?php
namespace App\Entidades;

abstract class TiposEntidade
{
    const Usuario = 1;
    const Cliente = 2;

}