<?php
namespace App\Entidades;

abstract class TiposIdentificacao
{
    const Residencial = 1;
    const Comercial = 2;
    const Personalizado = 3;

}