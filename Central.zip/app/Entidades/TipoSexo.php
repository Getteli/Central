<?php
namespace App\Entidades;

abstract class TipoSexo
{
    const Feminino = "M";
    const Masculino = "F";
    const Outros = "O";

}