<?php
namespace App\Entidades;

abstract class FormasPagamento
{
    const CartaoCredito = 1;
    const CartaoDebito = 2;
    const Boleto = 3;

}