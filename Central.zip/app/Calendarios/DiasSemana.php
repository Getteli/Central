<?php
namespace App\Calendarios;

abstract class DiasSemana
{
    const Domingo = 1;
    const SegundaFeira = 2;
    const TercaFeira = 3;
    const QuartaFeira = 4;
    const QuintaFeira = 5;
    const SextaFeira = 6;
    const Sabado = 7;

}