<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
        config(['app.locale' => \Config::get('app.locale')]);
        \Carbon\Carbon::setLocale(LC_TIME,\Config::get('app.locale'));
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        Carbon::setlocale(LC_TIME,\Config::get('app.locale'));
    }
}
