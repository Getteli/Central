<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Editar Segmento'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
    <div>
        <div>
            <div>
                <h1><?php echo e($segmento->segmento); ?></h1>
            </div>

            <div class="container">
                <div class="row">
                    <form action="<?php echo e(route('segmento.atualizar', $segmento->idSegmento)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('content.segmento._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <button class="btn blue">Atualizar</button>
                    </form>
                </div>
            </div>

            <?php if(Session::has('mensagem')): ?>
                <div>
                    <?php echo e(Session::get('mensagem')['msg']); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/segmento/editar.blade.php ENDPATH**/ ?>