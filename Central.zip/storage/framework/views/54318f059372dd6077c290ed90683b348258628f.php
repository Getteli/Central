<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Segmentos - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
    <div>
        <div>
            <div>
                <h1>listagem de segmentos</h1>
            </div>
            <div class="row">
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $segmentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($segmento->idSegmento); ?></td>
						<td><?php echo e($segmento->segmento); ?></td>
						<td>
                            <a class="btn blue"
                            href="<?php echo e(route('segmento.editar',[$segmento->idSegmento])); ?>">
                            Editar</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

            <?php if(Session::has('mensagem')): ?>
                <div>
                    <?php echo e(Session::get('mensagem')['msg']); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/segmento/segmentos.blade.php ENDPATH**/ ?>