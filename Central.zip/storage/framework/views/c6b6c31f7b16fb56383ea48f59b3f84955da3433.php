<!DOCTYPE html>
<html>
<head>
	<!-- Styles -->
	<!-- Compiled and minified CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/stylemaildefault.css')); ?>">
</head>
<body>
	<h3><?php echo e($TitleSMC); ?></h3>

	<p><b>Mensagem</b>: <br/>
	<?php echo e($MessageSMC); ?></p>

	<b>---</b>
	<br/>

	<p><b>Contato</b>: <?php echo e($ContactSMC); ?></p>
	<p><b>Nome</b>: <?php echo e($NameSMC); ?></p>
	<p><b>E-mail</b>: <?php echo e($EmailSMC); ?></p><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/email/client/layout.blade.php ENDPATH**/ ?>