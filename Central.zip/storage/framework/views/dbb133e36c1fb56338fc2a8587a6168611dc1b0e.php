<?php
	use App\Segmento;
?>

<div class="input-field">
	<input type="text" name="servico" class="validade" value="<?php echo e(isset($servico->servico) ? $servico->servico : ''); ?>">
	<label>Nome do Serviço</label>
</div>
<div class="input-field">
	<input type="text" name="descricao" required class="validade" value="<?php echo e(isset($servico->descricao) ? $servico->descricao : ''); ?>">
	<label>Descrição</label>
</div>
<div class="input-field">
	<input type="number" name="preco" class="validade" value="<?php echo e(isset($servico->preco) ? $servico->preco : ''); ?>">
	<label>Preço</label>
</div>
<div class="input-field">
	<select name="idSegmento" class="validade">
		<option value="">Selecione</option>
		<?php $__currentLoopData = Segmento::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($Segmento->idSegmento); ?>" <?php echo e(isset($servico->idSegmento) && $servico->idSegmento == $Segmento->idSegmento ? 'selected' : ''); ?>><?php echo e($Segmento->segmento); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Segmento</label>
</div><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/servico/_form.blade.php ENDPATH**/ ?>