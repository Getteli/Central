<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Novo Cliente'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
	<div>
		<div>
			<div>
				<h1>Novo cliente</h1>
			</div>

			<div class="container">
				<div class="row">
					<form action="<?php echo e(route('cliente.salvar')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<?php echo $__env->make('content.cliente._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<button type="button" id="btnAddEndereco">Add mais enderecos</button>
						<div class="row" id="divEndereco" style="border-style: dotted;">
							<div class="containerEndereco">
								<?php echo $__env->make('content.cliente._formEndereco', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
						<button type="button" id="btnAddContato">Add mais contato</button>
						<div class="row" id="divContato" style="border-style: dotted;">
							<div class="containerContato">
								<?php echo $__env->make('content.cliente._formContato', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
						<div class="row">
							<?php echo $__env->make('content.cliente._formPlano', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
						<button class="btn blue">Adicionar</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		$(".containerEndereco:first .btnDelE").attr("disabled", true);
		$("#btnAddEndereco").click(function(){
			$(".containerEndereco").last().clone().appendTo("#divEndereco");
			$(".containerEndereco:last-child .inputEndereco").val("");
			$(".containerEndereco:last-child .btnDelE").attr("disabled", false);

			$(".containerEndereco:last-child .select-wrapper input").remove();
			$(".containerEndereco:last-child .select-wrapper ul").remove();
			$(".containerEndereco:last-child .select-wrapper svg").remove();
			populaEstadoCidade();
		});

		function delFormEndereco() {
			$(".containerEndereco").last().remove();
		}

		$(".containerContato:first .btnDel").attr("disabled", true);
		$("#btnAddContato").click(function(){
			$(".containerContato").last().clone().appendTo("#divContato");
			$(".containerContato:last-child .inputContato").val("");
			$(".containerContato:last-child .btnDel").attr("disabled", false);
		});
		function delFormContato() {
			$(".containerContato").last().remove();
		}

		// buscar estado e cidades
		function populaEstadoCidade() {
			new dgCidadesEstados({
				cidade: document.getElementsByClassName('cid')[document.getElementsByClassName('cid').length-1],
				estado: document.getElementsByClassName('uf')[document.getElementsByClassName('uf').length-1]
				// para setar um valor:
				// estadoVal: '',
				// cidadeVal: ''
			})
			$('select').formSelect();
		}
		populaEstadoCidade();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/cliente/adicionar.blade.php ENDPATH**/ ?>