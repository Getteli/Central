<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Segmentos - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
	<div>
		<div>
			<h1>listagem de segmentos</h1>
		</div>
		<div class="row">
			<div class="col s12">
				<a href="<?php echo e(route('segmento.adicionar')); ?>">
				<button class="btn blue">Adicionar Segmento</button>
				</a>
			</div>
		</div>
		<div class="row">
			<form method="GET" action="<?php echo e(route('segmento.filter')); ?>">
				<div class="col l3 m4 s4">
					<input type="text" placeholder="texto" name="texto" value="<?php echo e($filtrar['texto'] ?? ''); ?>"/>
				</div>
				<div class="col l3 m4 s4">
					<select name="status">
						<option value="" <?php echo e(!isset($filtrar['status']) ? 'selected' : ''); ?>>Ativado & Desativado</option>
						<option value="1" <?php echo e(isset($filtrar['status']) && $filtrar['status'] == '1' ? 'selected' : ''); ?>>Ativado</option>
						<option value="0" <?php echo e(isset($filtrar['status']) && $filtrar['status'] == '0' ? 'selected' : ''); ?>>Desativado</option>
					</select>
				</div>
				<button type="submit" class="btn blue">Buscar</button>
			</form>
		</div>
		<div class="row">
			<p>total: <?php echo e($segmentos->count()); ?></p>
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $segmentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($segmento->idSegmento); ?></td>
						<td><?php echo e($segmento->segmento); ?></td>
						<td>
							<a class="btn blue"
							href="<?php echo e(route('segmento.editar',[$segmento->idSegmento])); ?>">
							Editar</a>
						</td>
						<td>
							<a class="btn red"
							href="<?php echo e(route('segmento.deleteSegmento',$segmento->idSegmento)); ?>">
							Excluir</a>
						</td>
						<?php if($segmento->ativo): ?>
						<td>
							<a class="btn green"
							href="<?php echo e(route('segmento.desativarSegmento',$segmento->idSegmento)); ?>">
							Desativar</a>
						</td>
						<?php else: ?>
						<td>
							<a class="btn green"
							href="<?php echo e(route('segmento.ativarSegmento',$segmento->idSegmento)); ?>">
							Ativar</a>
						</td>
						<?php endif; ?>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/segmento/segmentos.blade.php ENDPATH**/ ?>