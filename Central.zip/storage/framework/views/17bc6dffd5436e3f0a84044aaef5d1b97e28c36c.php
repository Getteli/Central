<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Novo Cliente'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
    <div>
        <div>
            <div>
                <h1>Novo cliente</h1>
            </div>

            <div class="container">
                <div class="row">
                    <form action="<?php echo e(route('cliente.salvar')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('content.cliente._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                        <?php echo $__env->make('content.cliente._formPlano', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <button class="btn blue">Adicionar</button>
                    </form>
                </div>
            </div>

            <?php if(Session::has('mensagem')): ?>
                <div>
                    <?php echo e(Session::get('mensagem')['msg']); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/cliente/adicionar.blade.php ENDPATH**/ ?>