<!DOCTYPE html>
<html>
<head>
	<!-- Styles -->
	<!-- Compiled and minified CSS -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dashb.css')); ?>">
</head>
<body>
	<h2><b>Erro ao</b> <?php echo e($TipoError); ?></h2>
	<p><b>Ocorreu em</b>: <?php echo e($MethodTarget); ?></p>
	<p><b>Quando</b>: <?php echo e($DateError); ?></p>
	<p><b>Erro</b>: <?php echo e($MessageError); ?></p><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/email/error/layout.blade.php ENDPATH**/ ?>