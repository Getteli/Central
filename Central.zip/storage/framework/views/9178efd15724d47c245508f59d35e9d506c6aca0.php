<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<!-- metas -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		
		<!-- CSRF Token -->
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<!-- titulo -->
		<title><?php echo $__env->yieldContent('title'); ?></title>

		<!-- Scripts -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<!-- Icones materilalize -->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<script src="<?php echo e(asset('js/cidades-estados.js')); ?>"></script>
		<!-- repete a chamada por conta do uso nos forms com materialize e api de estado cidade -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js"></script>
		<!-- Styles -->
		<!-- Compiled and minified CSS -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dashb.css')); ?>">
	</head>
	<body>
		<!-- navbar desktop -->
		<div class="navbar-fixed">
			<nav>
				<div class="nav-wrapper orange">
					<!-- logo -->
					<a href="<?php echo e(url('/')); ?>" class="brand-logo">Central</a>
					<!-- icone para abrir o navbar no mobile (carrega apenas em modo mobile) -->
					<a href="#" data-target="mobile-navbar" class="sidenav-trigger">
						<i class="material-icons">menu</i>
					</a>

					<ul id="navbar-items" class="hide-on-med-and-down right">
						<!-- entidade -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-ent">
							<i class="material-icons left">supervisor_account</i>
							Entid.
							<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-ent" class="dropdown-content">
								<li><a href="<?php echo e(route('clientes')); ?>">Clientes</a></li>
								<li><a href="<?php echo e(route('cliente.adicionar')); ?>">Adicionar cliente</a></li>
								<li class="divider"></li>
								<li><a href="#">Usuários</a></li>
								<li><a href="#">Adicionar usuários</a></li>
							</ul>
						</li>
						<!-- servicos -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-seg">
							<i class="material-icons left">style</i>
							Jobs
							<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-seg" class="dropdown-content">
								<li><a href="<?php echo e(route('segmentos')); ?>">Segmentos</a></li>
								<li><a href="<?php echo e(route('segmento.adicionar')); ?>">Criar segmentos</a></li>
								<li class="divider"></li>
								<li><a href="<?php echo e(route('servicos')); ?>">Serviços</a></li>
								<li><a href="<?php echo e(route('servico.adicionar')); ?>">Criar serviços</a></li>
							</ul>
						</li>
						<!-- Contas -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-pay">
							<i class="material-icons left">attach_money</i>
							Contas
							<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-pay" class="dropdown-content">
								<li><a href="#">Despesas</a></li>
								<li><a href="#">Adicionar uma despesa</a></li>
								<li class="divider"></li>
								<li><a href="#">Recebidos</a></li>
								<li class="divider"></li>
								<li><a href="<?php echo e(route('planos')); ?>">Listar planos</a></li>
							</ul>
						</li>
						<!-- calendario -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-dt">
							<i class="material-icons left">date_range</i>
							Datas
							<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-dt" class="dropdown-content">
								<li><a href="#">Datas</a></li>
								<li><a href="#">Criar uma nova data</a></li>
							</ul>
						</li>
						<!-- Tarefas -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-dt">
							<i class="material-icons left">view_list</i>
							Tarefas
							<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-dt" class="dropdown-content">
								<li><a href="#">Tarefas</a></li>
								<li><a href="#">Criar uma nova tarefa</a></li>
							</ul>
						</li>
						<!-- Configuracoes -->
						<li>
							<a href="#" class="dropdown-trigger" data-target="dropdown-conf">
								<i class="material-icons left">settings</i>
								Ajustes
								<i class="material-icons right">arrow_drop_down</i>
							</a>
							<ul id="dropdown-conf" class="dropdown-content">
								<li><a href="#">Configurações</a></li>
								<li><a href="#">Regras</a></li>
								<?php if(auth()->guard()->check()): ?>
									<li><a href="<?php echo e(route('logout')); ?>">Sair</a></li>
								<?php endif; ?>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<!-- navbar mobile -->
		<ul id="mobile-navbar" class="sidenav">
			<!-- entidade -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-ent">
				<i class="material-icons left">supervisor_account</i>
				Entidades
				<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-ent" class="dropdown-content">
					<li><a href="<?php echo e(route('clientes')); ?>">Clientes</a></li>
					<li><a href="<?php echo e(route('cliente.adicionar')); ?>">Adicionar cliente</a></li>
					<li class="divider"></li>
					<li><a href="#">Usuários</a></li>
					<li><a href="#">Adicionar usuários</a></li>
				</ul>
			</li>
			<!-- servicos -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-seg">
				<i class="material-icons left">style</i>
				Segmentos
				<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-seg" class="dropdown-content">
					<li><a href="<?php echo e(route('segmentos')); ?>">Segmentos</a></li>
					<li><a href="<?php echo e(route('segmento.adicionar')); ?>">Criar segmentos</a></li>
					<li class="divider"></li>
					<li><a href="<?php echo e(route('servicos')); ?>">Serviços</a></li>
					<li><a href="<?php echo e(route('servico.adicionar')); ?>">Criar serviços</a></li>
				</ul>
			</li>
			<!-- Contas -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-pay">
				<i class="material-icons left">attach_money</i>
				Contas
				<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-pay" class="dropdown-content">
					<li><a href="#">Despesas</a></li>
					<li><a href="#">Adicionar uma despesa</a></li>
					<li class="divider"></li>
					<li><a href="#">Recebidos</a></li>
					<li class="divider"></li>
					<li><a href="<?php echo e(route('planos')); ?>">Listar planos</a></li>
				</ul>
			</li>
			<!-- calendario -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-dt">
				<i class="material-icons left">date_range</i>
				Datas
				<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-dt" class="dropdown-content">
					<li><a href="#">Datas</a></li>
					<li><a href="#">Criar uma nova data</a></li>
				</ul>
			</li>
			<!-- Tarefas -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-dt">
				<i class="material-icons left">view_list</i>
				Tarefas
				<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-dt" class="dropdown-content">
					<li><a href="#">Tarefas</a></li>
					<li><a href="#">Criar uma nova tarefa</a></li>
				</ul>
			</li>
			<!-- Configuracoes -->
			<li>
				<a href="#" class="dropdown-trigger" data-target="dropdown-m-conf">
					<i class="material-icons left">settings</i>
					Ajustes
					<i class="material-icons right">arrow_drop_down</i>
				</a>
				<ul id="dropdown-m-conf" class="dropdown-content">
					<li><a href="#">Configurações</a></li>
					<li><a href="#">Regras</a></li>
					<?php if(auth()->guard()->check()): ?>
						<li><a href="<?php echo e(route('logout')); ?>">Sair</a></li>
					<?php endif; ?>
				</ul>
			</li>
		</ul>

		<!-- conteudo -->
		<div>
			<main>
				<?php echo $__env->yieldContent('content'); ?>
			</main>
		</div>

		<!-- error mensage -->
		<!-- <?php if(isset($errors) && count($errors)>0): ?>
			<div class="">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($erro); ?><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?> -->

		<!-- notification -->
		<?php if(Session::has('mensagem')): ?>
			<div id="meu-modal" class="modal <?php echo e(Session::get('mensagem')['class']); ?>">
				<div class="modal-content">
					<h4><?php echo e(Session::get('mensagem')['title']); ?></h4>
					<p><?php echo e(Session::get('mensagem')['msg']); ?></p>
				</div>
				<div class="modal-footer <?php echo e(Session::get('mensagem')['class-mc']); ?>">
					<a href="#" id="modal-close" class="modal-close white-text" style="">Fechar</a>
				</div>
			</div>
			<div class="sidenav-overlay <?php echo e(Session::get('mensagem')['class-so']); ?>"></div>
		<?php endif; ?>

		<!-- scripts -->
		<!-- Compiled and minified JavaScript -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
		<script src="<?php echo e(asset('js/dashb.js')); ?>"></script><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/layouts/main.blade.php ENDPATH**/ ?>