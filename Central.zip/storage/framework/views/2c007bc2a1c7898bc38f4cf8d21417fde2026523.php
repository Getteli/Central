<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Dashboard - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
	<div>
		<div>
			<div>
				<h1>Dashboard</h1>
				<?php
				$data = '2020-06-13 01:06:57';
				echo date("d-m-Y", strtotime($data));
				?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/dashboard.blade.php ENDPATH**/ ?>