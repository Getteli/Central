<?php
	use App\Servicos\FormasPagamento;
	use App\Entidades\TiposIdentificacao;
	use App\Segmento;
	use App\Servico;
?>
<h2>CONTATO</h2>
<?php
if(isset($contato->idContato)){
?>
<button type="button" class="btnDel" onclick="delContato(<?php echo e($contato->idContato); ?>)">EXCLUIR</button>
<?php
}else{
?>
<button type="button" class="btnDel" onclick="delFormContato()">EXCLUIR</button>
<?php
}
?>
<div class="input-field">
	<input type="number" maxlength="2" min="0" name="contatoForm[ddd][]" class="validade inputContato" value="<?php echo e(isset($contato->ddd) ? $contato->ddd : old('ddd')); ?>">
	<label>DDD</label>
</div>

<div class="input-field">
	<input type="text" id="numContatoLabel" maxlength="12" name="contatoForm[numeroContato][]" class="validade numero inputContato" value="<?php echo e(isset($contato->numero) ? $contato->numero : old('numeroContato')); ?>">
	<label for="numContatoLabel">Número (se for numero residencial sem o digito 9 na frente, coloque o numero 0)</label>
</div>

<div class="input-field">
	<input type="text" maxlength="45" name="contatoForm[emailContato][]" class="validade inputContato" value="<?php echo e(isset($contato->email) ? $contato->email : old('emailContato')); ?>">
	<label>E-mail</label>
</div>

<div class="input-field">
	<label>Identificação</label>

	<select name="contatoForm[identificacao][]" id="identificacaoContato" class="validade inputContato" maxlength="30">
		<option value="">Selecione</option>
		<?php $__currentLoopData = TiposIdentificacao::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($tipo); ?>" <?php echo e((isset($contato->identificacao) && $contato->identificacao == $tipo) || (old('identificacao') == $tipo) ? 'selected' : ''); ?>><?php echo e($tipo); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>

	<input type="text" disabled="disabled" id="identContatoManual" maxlength="30" name="contatoForm[identificacaoManual][]" class="validade inputContato none" placeholder="Digite a Identificação do contato" value="<?php echo e(isset($contato->identificacao) ? $contato->identificacao : old('identificacao')); ?>">
</div>

<script type="text/javascript">
	$('.numero').mask('0 0000-0000', {reverse: true});

	document.getElementById("identificacaoContato").addEventListener("change", function(){
		if (this.selectedIndex == 8) {
			$("#identContatoManual").removeClass("none");
			$("#identContatoManual").removeAttr("disabled");
		}
		if (this.selectedIndex != 8) {
			$("#identContatoManual").addClass("none");
			$("#identContatoManual").attr("disabled", "disabled");
		}
	});
</script><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/cliente/_formContato.blade.php ENDPATH**/ ?>