<?php if(isset($segmento->idSegmento)): ?>
<td>
	<a class="btn red"
	href="<?php echo e(route('segmento.deleteSegmento',$segmento->idSegmento)); ?>">
	Excluir</a>
</td>
<?php endif; ?>

<?php if(isset($segmento->ativo)): ?>
	<?php if($segmento->ativo): ?>
	<td>
		<a class="btn green"
		href="<?php echo e(route('segmento.desativarSegmento',$segmento->idSegmento)); ?>">
		Desativar</a>
	</td>
	<?php else: ?>
	<td>
		<a class="btn green"
		href="<?php echo e(route('segmento.ativarSegmento',$segmento->idSegmento)); ?>">
		Ativar</a>
	</td>
	<?php endif; ?>
<?php endif; ?>
<div class="input-field">
	<input type="text" name="segmento" maxlength="30" class="validade" value="<?php echo e(isset($segmento->segmento) ? $segmento->segmento : old('segmento')); ?>" required>
	<label>Nome do Segmento <strong style="color: red">*</strong></label>
</div>
<div class="input-field">
	<input type="text" name="descricao" maxlength="90" class="validade" value="<?php echo e(isset($segmento->descricao) ? $segmento->descricao : old('descricao')); ?>" required>
	<label>Descrição <strong style="color: red">*</strong></label>
</div><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/segmento/_form.blade.php ENDPATH**/ ?>