<div class="input-field">
	<input type="text" name="segmento" class="validade" value="<?php echo e(isset($segmento->segmento) ? $segmento->segmento : ''); ?>">
	<label>Nome do Segmento</label>
</div>
<div class="input-field">
	<input type="text" name="descricao" class="validade" value="<?php echo e(isset($segmento->descricao) ? $segmento->descricao : ''); ?>">
	<label>Descrição</label>
</div><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/segmento/_form.blade.php ENDPATH**/ ?>