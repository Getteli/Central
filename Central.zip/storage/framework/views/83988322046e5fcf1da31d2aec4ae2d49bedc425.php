<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Serviços - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
	<?php
		use App\Segmento;
	?>
	<div>
		<div>
			<h1>listagem de serviços</h1>
		</div>
		<div class="row">
			<div class="col s12">
				<a href="<?php echo e(route('servico.adicionar')); ?>">
				<button class="btn blue">Adicionar Serviço</button>
				</a>
			</div>
		</div>
		<div class="row">
			<form method="GET" action="<?php echo e(route('servico.filter')); ?>">
				<div class="col l3 m4 s4">
					<input type="text" placeholder="texto" name="texto" value="<?php echo e($filtrar['texto'] ?? ''); ?>"/>
				</div>
				<div class="col l3 m4 s4">
					<select name="status">
						<option value="" <?php echo e(!isset($filtrar['status']) ? 'selected' : ''); ?>>Ativado & Desativado</option>
						<option value="1" <?php echo e(isset($filtrar['status']) && $filtrar['status'] == '1' ? 'selected' : ''); ?>>Ativado</option>
						<option value="0" <?php echo e(isset($filtrar['status']) && $filtrar['status'] == '0' ? 'selected' : ''); ?>>Desativado</option>
					</select>
				</div>
				<div class="col l3 m4 s4">
					<select name="segmento">
						<option value="" <?php echo e(!isset($filtrar['segmento']) ? 'selected' : ''); ?>>Segmento</option>
						<?php $__currentLoopData = Segmento::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($Segmento->idSegmento); ?>" <?php echo e(isset($filtrar['segmento']) && $filtrar['segmento'] == $Segmento->idSegmento ? 'selected' : ''); ?>><?php echo e($Segmento->segmento); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<button type="submit" class="btn blue">Buscar</button>
			</form>
		</div>
		<div class="row">
			<p>total: <?php echo e($servicos->count()); ?></p>
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($servico->idServico); ?></td>
						<td><?php echo e($servico->servico); ?></td>
						<td>
							<a class="btn blue"
							href="<?php echo e(route('servico.editar',[$servico->idServico])); ?>">
							Editar</a>
						</td>
						<td>
							<a class="btn red"
							href="<?php echo e(route('servico.deleteServico',$servico->idServico)); ?>">
							Excluir</a>
						</td>
						<?php if($servico->ativo): ?>
						<td>
							<a class="btn green"
							href="<?php echo e(route('servico.desativarServico',$servico->idServico)); ?>">
							Desativar</a>
						</td>
						<?php else: ?>
						<td>
							<a class="btn green"
							href="<?php echo e(route('servico.ativarServico',$servico->idServico)); ?>">
							Ativar</a>
						</td>
						<?php endif; ?>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<?php if(Session::has('mensagem')): ?>
				<div>
					<?php echo e(Session::get('mensagem')['msg']); ?>

				</div>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/servico/servicos.blade.php ENDPATH**/ ?>