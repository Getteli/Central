<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Planos - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
	<?php
		use App\Segmento;
		use App\Servicos\FormasPagamento;
	?>
	<div>
		<div>
			<h1>Planos</h1>
		</div>
		<div class="row">
			<form method="GET" action="<?php echo e(route('plano.filter')); ?>">
				<div class="col l3 m4 s4">
					<input type="text" placeholder="texto" name="texto" value="<?php echo e($filtrar['texto'] ?? ''); ?>"/>
				</div>
				<div class="col l3 m4 s4">
					<input type="number" placeholder="até R$ valor" name="preco" min="0" value="<?php echo e($filtrar['preco'] ?? ''); ?>"/>
				</div>
				<div class="col l3 m4 s4">
					<select name="formaPagamento">
						<option value="" <?php echo e(!isset($filtrar['formaPagamento']) ? 'selected' : ''); ?>>Todas</option>
						<?php $__currentLoopData = FormasPagamento::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meioPagto => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($key); ?>" <?php echo e(isset($filtrar['formaPagamento']) && $filtrar['formaPagamento'] == $key ? 'selected' : ''); ?>><?php echo e($meioPagto); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<button type="submit" class="btn blue">Buscar</button>
			</form>
		</div>
		<div class="row">
			<p>total: <?php echo e($planos->count()); ?></p>
			<table>
				<thead>
					<tr>
						<th>Dia de Pagamento</th>
						<th>Forma</th>
						<th>Descrição</th>
						<th>Preço</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($plano->dataPagamento); ?></td>
						<td><?php echo e(FormasPagamento::getNameFPagamento($plano->formaPagamento)); ?></td>
						<td><?php echo e($plano->descricao); ?></td>
						<td><?php echo e("R$ ". number_format($plano->preco, 2)); ?></td>
						<td>
							<a class="btn blue"
							href="<?php echo e(route('plano.editar',[$plano->idPlano])); ?>">
							Editar</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<p>total: <b><?php echo e("R$ ". number_format($valorTotal, 2)); ?></b></p>
			
			<?php if(Session::has('mensagem')): ?>
				<div>
					<?php echo e(Session::get('mensagem')['msg']); ?>

				</div>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/plano/planos.blade.php ENDPATH**/ ?>