<?php
	use App\Segmento;
?>
<?php if(isset($servico->idServico)): ?>
<td>
	<a class="btn red"
	href="<?php echo e(route('servico.deleteServico',$servico->idServico)); ?>">
	Excluir</a>
</td>
<?php endif; ?>

<?php if(isset($servico->ativo)): ?>
	<?php if($servico->ativo): ?>
	<td>
		<a class="btn green"
		href="<?php echo e(route('servico.desativarServico',$servico->idServico)); ?>">
		Desativar</a>
	</td>
	<?php else: ?>
	<td>
		<a class="btn green"
		href="<?php echo e(route('servico.ativarServico',$servico->idServico)); ?>">
		Ativar</a>
	</td>
	<?php endif; ?>
<?php endif; ?>
<div class="input-field">
	<input type="text" name="servico" maxlength="30" class="validade" value="<?php echo e(isset($servico->servico) ? $servico->servico : old('servico')); ?>" required>
	<label>Nome do Serviço <strong style="color: red">*</strong></label>
</div>
<div class="input-field">
	<input type="text" name="descricao" maxlength="90" class="validade" value="<?php echo e(isset($servico->descricao) ? $servico->descricao : old('descricao')); ?>" required>
	<label>Descrição <strong style="color: red">*</strong></label>
</div>
<div class="input-field">
	<input type="text" name="preco" min="0" id="preco" class="validade" value="<?php echo e(isset($servico->preco) ? $servico->preco : old('preco')); ?>" required>
	<label>Preço <strong style="color: red">*</strong></label>
</div>
<div class="input-field">
	<select name="idSegmento" class="validade" required>
		<option value="">Selecione</option>
		<?php $__currentLoopData = Segmento::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($Segmento->idSegmento); ?>" <?php echo e((isset($servico->idSegmento) && $servico->idSegmento == $Segmento->idSegmento) || (old('idSegmento') == $Segmento->idSegmento ) ? 'selected' : ''); ?>><?php echo e($Segmento->segmento); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Segmento <strong style="color: red">*</strong></label>
</div>
<script type="text/javascript">
	$('#preco').mask('000000.00', {reverse: true});
</script><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/servico/_form.blade.php ENDPATH**/ ?>