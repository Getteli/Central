<!-- layout onde esse conteudo sera apresentado -->

<!-- titulo desta pagina -->
<?php $__env->startSection('title', 'Clientes - Central'); ?>
<!-- conteudo -->
<?php $__env->startSection('content'); ?>
    <div>
        <div>
            <div>
                <h1>listagem de clientes</h1>
            </div>
            <div class="row">
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>ent</th>
                        <th>Cnpj</th>
						<th>Razão Social</th>
						<th>Código de Cliente</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($cliente->idCliente); ?></td>
                        <td><?php echo e($cliente->idEntidade); ?></td>
						<td><?php echo e($cliente->cnpj); ?></td>
						<td><?php echo e($cliente->razaoSocial); ?></td>
						<td><?php echo e($cliente->codCliente); ?></td>
						<td>
                            <a class="btn blue"
                            href="<?php echo e(route('cliente.editar',[$cliente->idCliente, $cliente->idEntidade])); ?>">
                            Editar</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

            <?php if(Session::has('mensagem')): ?>
                <div>
                    <?php echo e(Session::get('mensagem')['msg']); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/cliente/clientes.blade.php ENDPATH**/ ?>