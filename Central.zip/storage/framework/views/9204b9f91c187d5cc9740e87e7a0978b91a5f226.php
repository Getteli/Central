<html>
<h1>Hello World</h1>
</html><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/email/default/layout.blade.php ENDPATH**/ ?>