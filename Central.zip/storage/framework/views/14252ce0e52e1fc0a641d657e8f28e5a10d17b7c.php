<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<!-- metas -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		
		<!-- CSRF Token -->
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

		<!-- titulo -->
		<title><?php echo $__env->yieldContent('title'); ?></title>

		<!-- Scripts -->
		<!-- Icones materilalize -->
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

		<!-- Styles -->
		<!-- Compiled and minified CSS -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	</head>
	<body>
		<div id="">
			<main class="">
				<?php echo $__env->yieldContent('content'); ?>
			</main>
		</div>

		<!-- <?php if(isset($errors) && count($errors)>0): ?>
			<div class="text-center mt-4 mb-4 p-2 alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($erro); ?><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?> -->

		<!-- notification -->
		<?php if(Session::has('mensagem')): ?>
			<div id="meu-modal" class="modal <?php echo e(Session::get('mensagem')['class']); ?>">
				<div class="modal-content">
					<h4><?php echo e(Session::get('mensagem')['title']); ?></h4>
					<p><?php echo e(Session::get('mensagem')['msg']); ?></p>
				</div>
				<div class="modal-footer <?php echo e(Session::get('mensagem')['class-mc']); ?>">
					<a href="#" id="modal-close" class="modal-close white-text" style="">Fechar</a>
				</div>
			</div>
			<div class="sidenav-overlay <?php echo e(Session::get('mensagem')['class-so']); ?>"></div>
		<?php endif; ?>

		<!-- scripts -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<!-- Compiled and minified JavaScript -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
		<script src="<?php echo e(asset('js/dashb.js')); ?>"></script><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/layouts/auth.blade.php ENDPATH**/ ?>