<?php
	use App\Servicos\FormasPagamento;
	use App\Segmento;
	use App\Servico;
?>
<h2>PLANO DO CLIENTE </h2>

<div class="input-field">
	<select multiple name="idServico" id="idServico" class="validade">
		<option value="" disabled>Selecione</option>
		<?php $__currentLoopData = Servico::all()->where('ativo', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($Servico->preco); ?>"><?php echo e($Servico->servico); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Serviços</label>
</div>

<div class="input-field <?php echo e(isset($plano->descricao) || !empty(old('descricao')) ? '' : 'none'); ?>">
	<input type="text" readonly name="descricao" maxlength="350" id="descricao" class="validade noEdit" value="<?php echo e(isset($plano->descricao) ? $plano->descricao : old('descricao')); ?>">
	<label>Descrição</label>
</div>
<div class="input-field">
	<input type="text" name="preco" id="preco" min="0" class="validade preco" value="<?php echo e(isset($plano->preco) ? $plano->preco : old('preco') ?? 0); ?>" required>
	<label>preco ( R$ )<strong style="color: red">*</strong></label>
</div>

<div class="input-field">
	<select name="formaPagamentoPlano" class="validade">
		<option value="">Selecione</option>
		<?php $__currentLoopData = FormasPagamento::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meioPagto => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($key); ?>" <?php echo e((isset($plano->formaPagamento) && $plano->formaPagamento == $key) || (old('formaPagamentoPlano') == $key) ? 'selected' : ''); ?>><?php echo e($meioPagto); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Forma de pagamento</label>
</div>

<div class="input-field">
	<input type="text" min="1" max="31" name="dataPagamentoPlano" id="dataPagamento" class="validade" value="<?php echo e(isset($plano->dataPagamento) ? $plano->dataPagamento : old('dataPagamentoPlano')); ?>" required>
	<label>DIA (Data de pagamento) <strong style="color: red">*</strong></label>
</div>	
<div class="input-field">
	<select type="text" name="especialLicense" class="validade">
		<option value="0" <?php echo e(( isset($license->special) ? $license->special : old('especialLicense') ?? 0 ) == 0 ? 'selected' : ''); ?>>Não</option1>
		<optgroup label="Temporário">
			<option value="1" <?php echo e(( isset($license->special) ? $license->special : old('especialLicense') ?? 0 ) == 1 ? 'selected' : ''); ?>>Apenas este cliente</option>
			<option value="2" <?php echo e(( isset($license->special) ? $license->special : old('especialLicense') ?? 0 ) == 2 ? 'selected' : ''); ?>>Promoção</option>
		</optgroup>
		<optgroup label="Sem tempo">
			<option value="3" <?php echo e(( isset($license->special) ? $license->special : old('especialLicense') ?? 0 ) == 3 ? 'selected' : ''); ?>>Vitalício</option>
			<option value="4" <?php echo e(( isset($license->special) ? $license->special : old('especialLicense') ?? 0 ) == 4 ? 'selected' : ''); ?>>Outros (manual)</option>
		</optgroup>
	</select>
	<label>É um cliente especial ? (ex: vitalicio, promoção, etc..)</label>
</div>

<div class="input-field">
	<input type="text" name="observacaoLicense" maxlength="100" class="validade" value="<?php echo e(isset($license->observacao) ? $license->observacao : old('observacaoLicense')); ?>">
	<label>Observação</label>
</div>

<div class="input-field <?php echo e(isset($license->codLicense) || !empty(old('codLicense')) ? '' : 'none'); ?>">
	<input readonly type="text" name="codLicense" class="validade noEdit" value="<?php echo e(isset($license->codLicense) ? $license->codLicense : old('codLicense')); ?>">
	<label>Código de licença</label>
</div>
<script>
	$('.preco').mask('#########.##', {reverse: true});
	// var aux
	var valor = 0;
	var desc = "";
	var descricao = document.getElementById("descricao");
	var preco = document.getElementById("preco");

	document.getElementById("idServico").addEventListener("change", function(){
		// passa por todos os options selecionados
		for(var i = 1; i < this.options.length; i++)
		{
			if(this.options[i].selected == true)
			{
				// coloca os valores e os nomes dos serviços
				valor += Number(this.options[i].value);
				desc += this.options[i].text + "; ";
			}
		}
		// add aos inputs
		preco.focus();
		preco.value = valor.toFixed(2);
		descricao.value = desc;
		preco.blur();

		// limpa os valores
		desc = "";
		valor = 0;
	});
</script><?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Agencia Publikando\Central\resources\views/content/cliente/_formPlano.blade.php ENDPATH**/ ?>