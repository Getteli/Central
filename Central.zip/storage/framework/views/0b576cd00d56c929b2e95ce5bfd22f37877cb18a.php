<?php
	use App\Servicos\FormasPagamento;
	use App\Segmento;
	use App\Servico;
?>
<h2>PLANO DO CLIENTE </h2>
<p>por um select com o segmento, e escolher pelo segmento os serviços, criar checkbox e ir marcando eles
colocando seus nomes na descricao + somando seus valores para o preço. select com tipos de pagamento</p>

<div class="input-field">
	<select name="idSegmento" id="idSegmento" class="validade">
		<option value="">Selecione</option>
		<?php $__currentLoopData = Segmento::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Segmento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($Segmento->idSegmento); ?>"><?php echo e($Segmento->segmento); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Segmento</label>
</div>

<div class="input-field">
	<select multiple name="idServico" class="validade">
		<option value="" disabled="disabled">Selecione</option>
		<?php $__currentLoopData = Servico::where('idSegmento','=', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($Servico->idServico); ?>"><?php echo e($Servico->servico); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Serviços</label>
</div>

<div class="input-field">
	<input type="text" name="descricao" class="validade" value="<?php echo e(isset($plano->descricao) ? $plano->descricao : ''); ?>">
	<label>Descrição</label>
</div>

<div class="input-field">
	<input type="number" name="preco" class="validade" value="<?php echo e(isset($plano->preco) ? $plano->preco : ''); ?>">
	<label>preco</label>
</div>

<div class="input-field">
	<select name="formaPagamentoPlano" class="validade">
		<option value="">Selecione</option>
		<?php $__currentLoopData = FormasPagamento::getAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meioPagto => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($key); ?>" <?php echo e(isset($plano->formaPagamento) && $plano->formaPagamento == $meioPagto ? 'selected' : ''); ?>><?php echo e($meioPagto); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<label>Forma de pagamento</label>
</div>

<div class="input-field">
	<input type="date" name="dataPagamentoPlano" class="validade" value="<?php echo e(isset($plano->dataPagamento) ? $plano->dataPagamento : ''); ?>">
	<label>Data de pagamento</label>
</div>

<script>
document.getElementById("idSegmento").addEventListener("change", function(){
	alert(this.value);
	/* com o id do segmento, eu envio via AJAX para uma rota que vai executar uma funcao que vai retornar
	a lista com os valores dos servicos
	OU criar um arquivo apenas para isso, que retorna.
	*/
});
</script>
<?php /**PATH C:\Users\Getteli\Desktop\Desktop\SERVIDORES ILION\usbwebserver 8.6.2\root\_NOS\Central\resources\views/content/cliente/_formPlano.blade.php ENDPATH**/ ?>